document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('dataForm');
    const displayDiv = document.getElementById('displayData');

    // Function to save data to local storage
    function saveData(name, employeeId, city, gender) {
        const data = {
            name: name,
            employeeId: employeeId,
            city: city,
            gender: gender
        };
        localStorage.setItem('userData', JSON.stringify(data));
    }

    // Function to display data
    function displaySavedData() {
        const userData = JSON.parse(localStorage.getItem('userData'));
        if (userData) {
            displayDiv.innerHTML = `
                <p><strong>Name:</strong> ${userData.name}</p>
                <p><strong>Employee Id:</strong> ${userData.employeeId}</p>
                <p><strong>City:</strong> ${userData.city}</p>
                <p><strong>Gender:</strong> ${userData.gender}</p>
            `;
        }
    }

    // Handle form submission
    form.addEventListener('submit', function(event) {
        event.preventDefault();
        const name = form.elements['name'].value;
        const employeeId = form.elements['employeeid'].value;
        const city = form.elements['city'].value;
        const maleChecked = form.elements['male'].checked;
        const femaleChecked = form.elements['female'].checked;
        let gender = "";
        if (maleChecked) {
            gender = "Male";
        }
        if (femaleChecked) {
            gender = "Female";
        }
        saveData(name, employeeId, city, gender);
        displaySavedData();
        form.reset();
    });

    // Enable editing upon clicking the name
    displayDiv.addEventListener('click', function() {
        const userData = JSON.parse(localStorage.getItem('userData'));
        if (userData) {
            const nameInput = `<input type="text" id="editName" value="${userData.name}">`;
            const employeeIdInput = `<input type="text" id="editEmployeeId" value="${userData.employeeId}">`;
            const cityInput = `
                <select id="editCity">
                    <option value="newyork" ${userData.city === 'New York' ? 'selected' : ''}>New York</option>
                    <option value="london" ${userData.city === 'London' ? 'selected' : ''}>London</option>
                    <option value="tokyo" ${userData.city === 'Tokyo' ? 'selected' : ''}>Tokyo</option>
                </select>
            `;
            const maleCheckbox = `<input type="checkbox" id="editMale" ${userData.gender === 'Male' ? 'checked' : ''}>`;
            const femaleCheckbox = `<input type="checkbox" id="editFemale" ${userData.gender === 'Female' ? 'checked' : ''}>`;
            displayDiv.innerHTML = `
                <label for="editName">Name:</label>${nameInput}<br />
                <label for="editEmployeeId">Employee Id:</label>${employeeIdInput}<br />
                <label for="editCity">City:</label>${cityInput}<br />
                <label for="editGender">Gender:</label>${maleCheckbox}Male ${femaleCheckbox}Female<br />
                <button id="saveEdit">Save</button>
            `;
            const saveEditBtn = document.getElementById('saveEdit');
            saveEditBtn.addEventListener('click', function() {
                const editedName = document.getElementById('editName').value;
                const editedEmployeeId = document.getElementById('editEmployeeId').value;
                const editedCity = document.getElementById('editCity').value;
                const editedMaleChecked = document.getElementById('editMale').checked;
                const editedFemaleChecked = document.getElementById('editFemale').checked;
                let editedGender = "";
                if (editedMaleChecked) {
                    editedGender = "Male";
                }
                if (editedFemaleChecked) {
                    editedGender = "Female";
                }
                saveData(editedName, editedEmployeeId, editedCity, editedGender);
                displaySavedData();
            });
        }
    });

});


